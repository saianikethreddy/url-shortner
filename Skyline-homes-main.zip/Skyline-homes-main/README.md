Full fledged Real Estate web application and cutting edge marketplace using MongoDB, Express, React and Node.js. It supports user‑friendly features to enhance the user experience with image uploads, property listing management, and more.


JWT, Firebase, and Google OAuth for secure and seamless user access, real‑world CRUD operations and advanced search functionality to help users find what they’re looking for.


Tech Stack : ReactJS, NodeJS, ExpressJS, MongoDB, Tailwind CSS.
